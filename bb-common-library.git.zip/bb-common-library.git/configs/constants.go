package configs

const (
	jsonType = "json"
	yamlType = "yaml"
	tomlType = "toml"
)
